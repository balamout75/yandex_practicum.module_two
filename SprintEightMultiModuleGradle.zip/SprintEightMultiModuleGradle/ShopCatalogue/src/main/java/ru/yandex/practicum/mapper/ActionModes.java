package ru.yandex.practicum.mapper;

public enum ActionModes {
    PLUS, MINUS, DELETE, NOTHING;
}
