package ru.yandex.practicum.dto.payment;

public enum ResultStatus {
    ACCEPTED, REJECTED, NOT_FOUND, UNAVAILABLE;
}
