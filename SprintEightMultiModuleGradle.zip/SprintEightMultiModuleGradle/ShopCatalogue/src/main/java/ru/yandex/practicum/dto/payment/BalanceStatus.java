package ru.yandex.practicum.dto.payment;

public enum BalanceStatus {
    ACCEPTED, USER_NOT_FOUND, SERVICE_NOT_FOUND, SERVICE_UNAVAILABLE;
}
