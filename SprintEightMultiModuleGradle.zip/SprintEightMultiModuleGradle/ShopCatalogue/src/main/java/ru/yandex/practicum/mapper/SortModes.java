package ru.yandex.practicum.mapper;

public enum SortModes {
    ALPHA, PRICE, NO;
}
