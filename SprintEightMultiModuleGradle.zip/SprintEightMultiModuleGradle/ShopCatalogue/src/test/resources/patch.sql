insert into testdb.order_items values (1, 1, 10),
                               (1, 2, 9),
                               (1, 3, 8);