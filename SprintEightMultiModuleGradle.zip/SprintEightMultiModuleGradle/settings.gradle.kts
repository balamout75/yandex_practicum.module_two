rootProject.name = "SprintSevenMultiModuleGradle"
include("ShopCatalogue")
include("ShopPayment")